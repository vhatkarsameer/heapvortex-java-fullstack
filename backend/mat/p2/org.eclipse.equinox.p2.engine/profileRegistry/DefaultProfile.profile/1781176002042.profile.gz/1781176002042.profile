<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1781176002042'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/agent/workspace/mat-standalone-packages/org.eclipse.mat.product/target/products/org.eclipse.mat.ui.rcp.MemoryAnalyzer/linux/gtk/x86_64/mat'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/agent/workspace/mat-standalone-packages/org.eclipse.mat.product/target/products/org.eclipse.mat.ui.rcp.MemoryAnalyzer/linux/gtk/x86_64/mat'/>
  </properties>
</profile>
